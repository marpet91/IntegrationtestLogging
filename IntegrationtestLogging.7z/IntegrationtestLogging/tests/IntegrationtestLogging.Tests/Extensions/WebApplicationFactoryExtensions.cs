using System;
using IntegrationtestLogging.Tests.Loggers;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Console;
using Xunit.Abstractions;

namespace IntegrationtestLogging.Tests.Extensions;

public static class WebApplicationFactoryExtensions
{
    public static WebApplicationFactory<TStartup> WithTestLogging<TStartup>(
        this WebApplicationFactory<TStartup> factory, ITestOutputHelper output) where TStartup : class
    {
        return factory.WithWebHostBuilder(builder =>
        {
            builder.ConfigureLogging(logging =>
            {
                var useScopes = logging.UsesScopes();
                logging.ClearProviders();
                logging.Services.AddSingleton<ILoggerProvider>(r => new XunitLoggerProvider(output, useScopes));
            });
        });
    }

    private static bool UsesScopes(this ILoggingBuilder builder)
    {
        var serviceProvider = builder.Services.BuildServiceProvider();

        var options = GetHostBuildersCallingConfigureLoggingExplicitly(serviceProvider);
        if (options != default)
        {
            return options.IncludeScopes;
        }

        var config = serviceProvider.GetService<IConfigurationRoot>() ?? serviceProvider.GetService<IConfiguration>();
        var logging = config?.GetSection("Logging");
        if (logging == default)
        {
            return false;
        }

        var includeScopes = logging?.GetValue("Console:IncludeScopes", false);
        if (!includeScopes.Value)
        {
            includeScopes = logging?.GetValue("IncludeScopes", false);
        }

        return includeScopes.GetValueOrDefault(false);
    }

    private static ConsoleFormatterOptions? GetHostBuildersCallingConfigureLoggingExplicitly(
        IServiceProvider serviceProvider)
    {
        var options = serviceProvider.GetService<SimpleConsoleFormatterOptions>() ??
                      serviceProvider.GetService<JsonConsoleFormatterOptions>() ??
                      serviceProvider.GetService<ConsoleFormatterOptions>();
        return options;
    }
}