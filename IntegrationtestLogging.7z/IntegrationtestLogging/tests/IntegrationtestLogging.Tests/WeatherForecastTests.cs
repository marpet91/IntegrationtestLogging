﻿using System.Net;
using System.Threading.Tasks;
using IntegrationtestLogging.Tests.Extensions;
using Microsoft.AspNetCore.Mvc.Testing;
using Xunit;
using Xunit.Abstractions;

namespace IntegrationtestLogging.Tests;

public class WeatherForecastTests : IClassFixture<WebApplicationFactory<Program>>
{
    private readonly WebApplicationFactory<Program> _factory;

    public WeatherForecastTests(ITestOutputHelper output, WebApplicationFactory<Program> factory)
    {
        _factory = factory.WithTestLogging(output);
    }

    [Theory]
    [InlineData("/WeatherForecast")]
    public async Task Get_Route_Returns_Response(string url)
    {
        var client = _factory.CreateClient(new WebApplicationFactoryClientOptions {AllowAutoRedirect = false});
        var response = await client.GetAsync(url);
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
    }
}
